package com.example.tankovkorneev;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        TextView nadpis=(TextView) findViewById(R.id.nadpis);
        switch (id){
            case R.id.blue:
                nadpis.setTextColor(Color.BLUE);
                return true;
            case R.id.red:
                nadpis.setTextColor(Color.RED);
                return true;
            case R.id.small_font:
                nadpis.setTextSize(10);
                return true;
            case R.id.big_font:
                nadpis.setTextSize(30);
                return true;
            case R.id.ru:
                nadpis.setText("Привет");
                return true;
            case R.id.ukr:
                nadpis.setText("Здоров");
                return true;
            case R.id.background_rgb1:
                nadpis.setBackgroundColor(Color.argb(255,255,154,204));
                return true;
            case R.id.background_rgb2:
                nadpis.setBackgroundColor(Color.argb(255, 153,0,0));
                return true;
            case R.id.background_green:
                nadpis.setBackgroundColor(Color.GREEN);



        }
        return super.onOptionsItemSelected(item);

    }
}