package com.example.tankovkorneev;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
/*-ё*/
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView rezult;
    private Button plus;
    private Button minus;
    private Button umnoj;
    private Button delenie;
    private EditText vvesti1;
    private EditText vvesti2;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button perehod=(Button)findViewById(R.id.perehod);
        perehod.setOnClickListener(this);
        vvesti1=(EditText) findViewById(R.id.vvesti1);
        vvesti2=(EditText) findViewById(R.id.vvesti2);
        plus=(Button) findViewById(R.id.plus);
        minus=(Button) findViewById(R.id.minus);
        umnoj=(Button) findViewById(R.id.umnoj);
        delenie=(Button) findViewById(R.id.delenie);
        rezult=(TextView) findViewById(R.id.rezult);

        plus.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double a,b,c;
                String S1=vvesti1.getText().toString();
                String S2=vvesti2.getText().toString();
                a=Double.parseDouble(S1);
                b=Double.parseDouble(S2);
                c=a+b;
                String S=Double.toString(c);
                rezult.setText(S);


            }

        }
        );
        minus.setOnClickListener (new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         Double a,b,c;
                                         String S1=vvesti1.getText().toString();
                                         String S2=vvesti2.getText().toString();
                                         a=Double.parseDouble(S1);
                                         b=Double.parseDouble(S2);
                                         c=a-b;
                                         String S=Double.toString(c);
                                         rezult.setText(S);


                                     }

                                 }
        );
        umnoj.setOnClickListener (new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         Double a,b,c;
                                         String S1=vvesti1.getText().toString();
                                         String S2=vvesti2.getText().toString();
                                         a=Double.parseDouble(S1);
                                         b=Double.parseDouble(S2);
                                         c=a*b;
                                         String S=Double.toString(c);
                                         rezult.setText(S);


                                     }

                                 }
        );
        delenie.setOnClickListener (new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         Double a,b,c;
                                         String S1=vvesti1.getText().toString();
                                         String S2=vvesti2.getText().toString();
                                         a=Double.parseDouble(S1);
                                         b=Double.parseDouble(S2);
                                         c=a/b;
                                         String S=Double.toString(c);
                                         rezult.setText(S);


                                     }

                                 }
        );


    }

    @Override
    public void onClick(View view) {
        Intent intent;
        intent=new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
}